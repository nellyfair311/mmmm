package com.nellykidsfashion.plateau

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
