// Export pages
export '/pages/home/home_widget.dart' show HomeWidget;
export '/pages/nelly/nelly_widget.dart' show NellyWidget;
export '/pages/menu/menu_widget.dart' show MenuWidget;
export '/pages/nilly/nilly_widget.dart' show NillyWidget;
export '/pages/moda/moda_widget.dart' show ModaWidget;
export '/pages/about_us/about_us_widget.dart' show AboutUsWidget;
export '/pages/free_transportation/free_transportation_widget.dart'
    show FreeTransportationWidget;
